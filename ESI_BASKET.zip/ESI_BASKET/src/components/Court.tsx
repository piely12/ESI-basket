import { initialPlayers } from "@/lib/data";

const spots: [number, number][] = [[50, 18], [18, 40], [82, 40], [30, 72], [70, 72]];
export function Court({ starters }: { starters: number[] }) {
  return (
    <div className="relative mx-auto aspect-[4/3] w-full max-w-md overflow-hidden rounded-lg border-2 border-gold bg-gold/20">
      <div className="absolute left-1/2 top-0 h-[45%] w-[34%] -translate-x-1/2 border-2 border-t-0 border-gold" />
      <div className="absolute left-1/2 top-0 h-[80%] w-[80%] -translate-x-1/2 rounded-b-full border-2 border-t-0 border-gold" />
      {starters.map((n, i) => {
        const p = initialPlayers.find((x) => x.num === n)!;
        return (
          <div key={n} className="absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center" style={{ left: `${spots[i]![0]}%`, top: `${spots[i]![1]}%` }}>
            <div className="font-display grid h-11 w-11 place-items-center rounded-full bg-primary text-xl text-primary-foreground ring-2 ring-gold">{n}</div>
            <div className="mt-1 rounded bg-card px-1.5 text-[10px] font-bold">{p.last}</div>
          </div>
        );
      })}
    </div>
  );
}
