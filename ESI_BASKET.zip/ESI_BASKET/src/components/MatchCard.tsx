import { Link } from "@tanstack/react-router";
import { fmtDate, team, type Match } from "@/lib/data";
import { Logo } from "./Shell";

export function MatchCard({ m, big = false }: { m: Match; big?: boolean }) {
  const esi = m.home === "esi" || m.away === "esi";
  const won = m.score && ((m.home === "esi" && m.score[0] > m.score[1]) || (m.away === "esi" && m.score[1] > m.score[0]));
  return (
    <Link to="/matchs/$id" params={{ id: m.id }} className={`block rounded-lg border p-4 transition hover:-translate-y-0.5 ${esi ? "border-gold bg-card" : "border-border bg-card/60"}`}>
      <div className="mb-3 flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        <span>{fmtDate(m.date)} · {m.time}</span>
        {m.score ? (esi && <span className={won ? "text-gold-deep" : "text-destructive"}>{won ? "Victoire" : "Défaite"}</span>) : <span>À venir</span>}
      </div>
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
        {[m.home, m.away].map((id, i) => (
          <div key={id} className={`flex items-center gap-2 ${i ? "order-3 flex-row-reverse text-right" : ""}`}>
            <Logo id={id} className={big ? "h-16 w-16" : "h-10 w-10"} />
            <span className={`font-display ${big ? "text-3xl" : "text-xl"} ${id === "esi" ? "text-primary" : ""}`}>{team(id).name}</span>
          </div>
        ))}
        <div className={`order-2 font-display ${big ? "text-5xl" : "text-3xl"} text-primary`}>
          {m.score ? `${m.score[0]}–${m.score[1]}` : "VS"}
        </div>
      </div>
      <div className="mt-2 text-center text-xs text-muted-foreground">{m.venue}</div>
    </Link>
  );
}
