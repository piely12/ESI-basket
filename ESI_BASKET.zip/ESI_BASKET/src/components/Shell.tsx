import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { Home, CalendarDays, Trophy, Users, Newspaper, Settings, Lock } from "lucide-react";
import { team } from "@/lib/data";

const nav = [
  { to: "/", label: "Accueil", icon: Home },
  { to: "/matchs", label: "Matchs", icon: CalendarDays },
  { to: "/classement", label: "Classement", icon: Trophy },
  { to: "/equipe", label: "Équipe", icon: Users },
  { to: "/actualites", label: "Actus", icon: Newspaper },
  { to: "/reglages", label: "Réglages", icon: Settings },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background pb-24 md:pb-0">
      <header className="sticky top-0 z-30 border-b border-border bg-primary text-primary-foreground">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-2">
          <Link to="/" className="flex min-w-0 items-center gap-2">
            <img src={team("esi").logo} alt="The Lions of ESI" className="h-10 w-10 shrink-0 object-contain" />
            <div className="min-w-0 leading-none">
              <div className="font-display truncate text-2xl tracking-wide text-gold">THE LIONS OF ESI</div>
              <div className="truncate text-[10px] uppercase tracking-[0.2em] opacity-80">Inter-Écoles INP-HB</div>
            </div>
          </Link>
          <nav className="hidden gap-1 md:flex">
            {nav.map((n) => (
              <Link key={n.to} to={n.to} activeOptions={{ exact: n.to === "/" }} className="rounded px-3 py-1.5 text-sm font-semibold uppercase tracking-wide opacity-80 hover:opacity-100" activeProps={{ className: "bg-gold text-gold-foreground opacity-100" }}>
                {n.label}
              </Link>
            ))}
          </nav>
          <Link to="/espaces" className="flex shrink-0 items-center gap-1 rounded border border-gold/60 px-2.5 py-1.5 text-xs font-bold uppercase text-gold">
            <Lock className="h-3.5 w-3.5" /> Espaces
          </Link>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-6">{children}</main>
      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-6 border-t border-border bg-card md:hidden">
        {nav.map((n) => (
          <Link key={n.to} to={n.to} activeOptions={{ exact: n.to === "/" }} className="flex flex-col items-center gap-0.5 py-2 text-[10px] font-semibold text-muted-foreground" activeProps={{ className: "text-primary" }}>
            <n.icon className="h-5 w-5" />
            {n.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}

export function Title({ kicker, children }: { kicker?: string; children: ReactNode }) {
  return (
    <div className="mb-5">
      {kicker && <div className="text-xs font-bold uppercase tracking-[0.25em] text-gold-deep">{kicker}</div>}
      <h1 className="font-display text-4xl leading-none text-primary md:text-5xl">{children}</h1>
    </div>
  );
}

export function Logo({ id, className = "h-10 w-10" }: { id: string; className?: string }) {
  const t = team(id);
  return <img src={t.logo} alt={t.name} className={`${className} shrink-0 object-contain`} />;
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-lg border border-border bg-card p-4 ${className}`}>{children}</div>;
}
