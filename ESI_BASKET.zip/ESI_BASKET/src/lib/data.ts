import esi from "@/assets/logos/esi.png.asset.json";
import esmg from "@/assets/logos/esmg.png.asset.json";
import esa from "@/assets/logos/esa.png.asset.json";
import epge from "@/assets/logos/epge.png.asset.json";
import escae from "@/assets/logos/escae.png.asset.json";
import escpe from "@/assets/logos/escpe.png.asset.json";
import ep from "@/assets/logos/ep.png.asset.json";
import estp from "@/assets/logos/estp.png.asset.json";

export const TODAY = "2026-09-25";

export type Team = { id: string; name: string; full: string; logo: string };
export const teams: Team[] = [
  { id: "esi", name: "ESI", full: "The Lions of ESI", logo: esi.url },
  { id: "esmg", name: "ESMG", full: "ESMG Sports Team", logo: esmg.url },
  { id: "esa", name: "ESA", full: "ESA Sports Team", logo: esa.url },
  { id: "epge", name: "EPGE", full: "EPGE Sharks", logo: epge.url },
  { id: "escae", name: "ESCAE", full: "ESCAE Business School", logo: escae.url },
  { id: "escpe", name: "ESCPE", full: "ESCPE Tigers", logo: escpe.url },
  { id: "ep", name: "E.PROJETS", full: "Écoles Sup. des Projets", logo: ep.url },
  { id: "estp", name: "ESTP", full: "ESTP Sports Team", logo: estp.url },
];
export const team = (id: string) => teams.find((t) => t.id === id)!;

export type Status = "actif" | "blessé" | "suspendu";
export type Player = { num: number; last: string; first: string; pos: string; status: Status };
const raw: [number, string, string, string][] = [
  [1, "KOUAME", "Miguel", "Meneur / Arrière"],
  [2, "KOUAO", "Chris-Ivann", "Meneur"],
  [3, "KEITA", "Almamy", "Arrière"],
  [4, "BOTCHI", "Pethuel", "Meneur"],
  [5, "COULIBALY ZIE", "Imad", "Ailier"],
  [6, "M’BOUA", "Salomon", "Arrière / Ailier"],
  [7, "AMON", "Loïc-Othniel", "Meneur / Arrière / Ailier"],
  [8, "GBAGO", "Marc", "Ailier"],
  [9, "NEBIE", "Ange Michel", "Meneur"],
  [10, "KOUASSI", "Famien", "Pivot"],
  [11, "KOUAO", "Darryl Junior", "Pivot"],
  [12, "DALOUGOU", "Chris-Israël", "Arrière"],
  [13, "KOCLA KOUAKOU", "Alex", "Ailier fort / Pivot"],
  [14, "KONAN LOUKOU", "Ange", "Ailier / Ailier fort"],
  [15, "KOUAKOU", "Vincent de Paul", "Meneur / Arrière"],
  [16, "KOUMOIN", "Péniel", "Ailier / Ailier fort"],
  [17, "YOBOUE KOUAME", "Jean Lois", "Ailier / Ailier fort"],
];
export const initialPlayers: Player[] = raw.map(([num, last, first, pos]) => ({
  num, last, first, pos,
  status: num === 8 ? "blessé" : num === 12 ? "suspendu" : "actif",
}));
export const posGroups = ["Meneur", "Arrière", "Ailier", "Ailier fort", "Pivot"];

export type StatLine = {
  num: number; min: number; pts: number; reb: number; ast: number; stl: number; blk: number;
  to: number; fgm: number; fga: number; tpm: number; tpa: number; ftm: number; fta: number; pm: number;
};
export type Match = {
  id: string; home: string; away: string; date: string; time: string; venue: string;
  score?: [number, number]; stats?: StatLine[]; starters?: number[]; bench?: number[];
};

function seedStats(seed: number, nums: number[], total: number): StatLine[] {
  let s = seed;
  const r = (m: number) => { s = (s * 9301 + 49297) % 233280; return Math.floor((s / 233280) * m); };
  const lines = nums.map((num, i) => {
    const fga = 3 + r(10), fgm = Math.min(fga, 1 + r(6)), tpa = r(5), tpm = Math.min(tpa, r(3)), fta = r(6), ftm = Math.min(fta, r(5));
    return { num, min: i < 5 ? 24 + r(10) : 6 + r(14), pts: 0, reb: r(9), ast: r(7), stl: r(4), blk: r(3), to: r(4), fgm, fga, tpm, tpa, ftm, fta, pm: r(21) - 8 };
  });
  lines.forEach((l) => (l.pts = (l.fgm - l.tpm) * 2 + l.tpm * 3 + l.ftm));
  const diff = total - lines.reduce((a, l) => a + l.pts, 0);
  const f = lines[0]!; f.pts = Math.max(0, f.pts + diff);
  return lines;
}
const sq1 = [1, 7, 10, 13, 14, 2, 3, 5, 9, 11, 15, 16];
const sq2 = [2, 6, 10, 14, 17, 1, 3, 4, 7, 11, 13, 15];

export const matches: Match[] = [
  { id: "m1", home: "esi", away: "esa", date: "2026-09-05", time: "16:00", venue: "Gymnase INP-HB Centre", score: [68, 54], stats: seedStats(3, sq1, 68), starters: sq1.slice(0, 5), bench: sq1.slice(5) },
  { id: "m2", home: "estp", away: "esi", date: "2026-09-12", time: "18:00", venue: "Gymnase INP-HB Nord", score: [61, 64], stats: seedStats(7, sq2, 64), starters: sq2.slice(0, 5), bench: sq2.slice(5) },
  { id: "m3", home: "esi", away: "escae", date: "2026-09-19", time: "17:00", venue: "Gymnase INP-HB Centre", score: [57, 60], stats: seedStats(11, sq1, 57), starters: sq1.slice(0, 5), bench: sq1.slice(5) },
  { id: "m4", home: "esi", away: "esmg", date: "2026-09-25", time: "18:30", venue: "Gymnase INP-HB Centre", starters: [1, 7, 10, 13, 14], bench: [2, 3, 5, 9, 11, 15, 16] },
  { id: "m5", home: "escpe", away: "esi", date: "2026-10-03", time: "16:00", venue: "Gymnase INP-HB Sud" },
  { id: "m6", home: "esi", away: "epge", date: "2026-10-10", time: "17:30", venue: "Gymnase INP-HB Centre" },
  { id: "m7", home: "ep", away: "esi", date: "2026-10-17", time: "18:00", venue: "Gymnase INP-HB Nord" },
  { id: "o1", home: "esmg", away: "escpe", date: "2026-09-06", time: "16:00", venue: "Gymnase INP-HB Sud", score: [55, 49] },
  { id: "o2", home: "epge", away: "ep", date: "2026-09-13", time: "16:00", venue: "Gymnase INP-HB Sud", score: [47, 52] },
  { id: "o3", home: "escae", away: "estp", date: "2026-09-13", time: "18:00", venue: "Gymnase INP-HB Centre", score: [66, 58] },
  { id: "o4", home: "esa", away: "epge", date: "2026-09-20", time: "16:00", venue: "Gymnase INP-HB Nord", score: [59, 62] },
];
export const staff = ["Coach principal — M. KONÉ Adama", "Coach adjoint — M. YAO Serge", "Statisticienne — Mlle ASSI Grâce"];

export const isPlayed = (m: Match) => !!m.score;
export const isEsi = (m: Match) => m.home === "esi" || m.away === "esi";
export const lineupVisible = (m: Match) => m.date <= TODAY; // RB-COMPO-001 (à appliquer côté base en prod)

export function standings() {
  const t: Record<string, { id: string; j: number; v: number; d: number; pp: number; pc: number }> = {};
  teams.forEach((x) => (t[x.id] = { id: x.id, j: 0, v: 0, d: 0, pp: 0, pc: 0 }));
  matches.filter(isPlayed).forEach((m) => {
    const [h, a] = m.score!;
    const H = t[m.home]!, A = t[m.away]!;
    H.j++; A.j++; H.pp += h; H.pc += a; A.pp += a; A.pc += h;
    if (h > a) { H.v++; A.d++; } else { A.v++; H.d++; }
  });
  return Object.values(t)
    .map((r) => ({ ...r, pts: r.v * 2 + r.d, diff: r.pp - r.pc }))
    .sort((a, b) => b.pts - a.pts || b.diff - a.diff);
}

export function playerTotals(num: number) {
  const games = matches.filter((m) => m.stats?.some((s) => s.num === num)).map((m) => ({ m, s: m.stats!.find((s) => s.num === num)! }));
  const sum = (k: keyof StatLine) => games.reduce((a, g) => a + (g.s[k] as number), 0);
  return { games, gp: games.length, pts: sum("pts"), reb: sum("reb"), ast: sum("ast"), stl: sum("stl"), blk: sum("blk"), pm: sum("pm") };
}

export type News = { id: string; title: string; tag: string; date: string; body: string; mvp?: number | undefined };
export const initialNews: News[] = [
  { id: "n1", title: "Victoire de caractère à l'extérieur face à l'ESTP", tag: "Match", date: "2026-09-13", body: "Les Lions s'imposent 64-61 au terme d'un money-time maîtrisé.", mvp: 7 },
  { id: "n2", title: "MVP de la semaine : KOUASSI Famien", tag: "MVP", date: "2026-09-20", body: "Dominant dans la raquette malgré la défaite contre l'ESCAE.", mvp: 10 },
  { id: "n3", title: "GBAGO Marc indisponible trois semaines", tag: "Indisponibilité", date: "2026-09-21", body: "Entorse de la cheville : retour prévu mi-octobre." },
  { id: "n4", title: "Choc ce soir face à l'ESMG", tag: "Avant-match", date: "2026-09-25", body: "Rendez-vous à 18h30 au Gymnase INP-HB Centre. Venez en bordeaux !" },
];
export const hallOfFame = [
  { year: "2025", title: "Finaliste Inter-Écoles INP-HB" },
  { year: "2024", title: "Demi-finaliste — Meilleure défense" },
  { year: "2023", title: "Champion Inter-Écoles INP-HB" },
];

export const fullName = (p: Player) => `${p.last} ${p.first}`;
export const fmtDate = (d: string) => new Date(d + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "short", day: "numeric", month: "short" });
