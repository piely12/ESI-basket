export const seo = (title: string, description: string) => ({
  meta: [
    { title: `${title} — The Lions of ESI` },
    { name: "description", content: description },
    { property: "og:title", content: `${title} — The Lions of ESI` },
    { property: "og:description", content: description },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ],
});
