import { useSyncExternalStore } from "react";
import { initialNews, initialPlayers, type News, type Player, type Status, type StatLine } from "./data";

export type Notif = { id: string; to: number; text: string; date: string; read: boolean };
type State = {
  players: Player[];
  convocations: Record<string, number[]>; // matchId -> validated list
  lineups: Record<string, { starters: number[]; bench: number[] }>;
  notifs: Notif[];
  news: News[];
  liveStats: Record<string, StatLine>;
  statsValidated: boolean;
  audit: string[];
};
let state: State = {
  players: initialPlayers,
  convocations: {},
  lineups: {},
  notifs: [],
  news: initialNews,
  liveStats: {},
  statsValidated: false,
  audit: [],
};
const subs = new Set<() => void>();
export function set(fn: (s: State) => Partial<State>) {
  state = { ...state, ...fn(state) };
  subs.forEach((f) => f());
}
export function useStore<T>(sel: (s: State) => T): T {
  return useSyncExternalStore(
    (f) => { subs.add(f); return () => subs.delete(f); },
    () => sel(state),
    () => sel(state),
  );
}
export const setStatus = (num: number, status: Status) =>
  set((s) => ({ players: s.players.map((p) => (p.num === num ? { ...p, status } : p)) }));

// RB-NOTIF-001 : notifier uniquement les convoqués, sans doublon sauf modification officielle
export function validateConvocation(matchId: string, list: number[], label: string) {
  set((s) => {
    const prev = s.convocations[matchId] ?? [];
    const changed = prev.length !== list.length || list.some((n) => !prev.includes(n));
    if (!changed) return {};
    const date = new Date().toISOString();
    const isUpdate = prev.length > 0;
    const notifs = list
      .map((n) => ({ id: `${matchId}-${n}-${date}`, to: n, date, read: false, text: `${isUpdate ? "Mise à jour : " : ""}Vous êtes convoqué pour ${label}.` }));
    return {
      convocations: { ...s.convocations, [matchId]: list },
      notifs: [...notifs, ...s.notifs],
      audit: [`${date} — convocation ${matchId} (${list.length} joueurs)`, ...s.audit],
    };
  });
}
