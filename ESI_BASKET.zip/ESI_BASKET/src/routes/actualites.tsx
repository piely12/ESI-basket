import { createFileRoute } from "@tanstack/react-router";
import { hallOfFame, initialPlayers, fmtDate } from "@/lib/data";
import { useStore } from "@/lib/store";
import { Card, Title } from "@/components/Shell";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/actualites")({
  head: () => seo("Actualités", "MVP, actus de l'équipe, indisponibilités et Hall of Fame des Lions de l'ESI."),
  component: Actus,
});

function Actus() {
  const news = useStore((s) => s.news);
  const mvp = news.find((n) => n.mvp);
  const mp = mvp && initialPlayers.find((p) => p.num === mvp.mvp);
  return (
    <div className="space-y-6">
      <Title kicker="Le journal des Lions">Actualités</Title>
      {mp && (
        <div className="rounded-xl bg-gold p-6 text-gold-foreground">
          <div className="text-xs font-bold uppercase tracking-[0.3em]">MVP post-match</div>
          <div className="font-display text-6xl leading-none">#{mp.num} {mp.last}</div>
          <p className="mt-1">{mvp!.title}</p>
        </div>
      )}
      <div className="flex snap-x gap-3 overflow-x-auto pb-2">
        {news.map((n) => (
          <Card key={n.id} className="min-w-[260px] snap-start md:min-w-[300px]">
            <div className="flex justify-between text-xs"><span className="rounded bg-primary px-2 py-0.5 font-bold uppercase text-primary-foreground">{n.tag}</span><span className="text-muted-foreground">{fmtDate(n.date)}</span></div>
            <h3 className="mt-2 font-semibold">{n.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{n.body}</p>
          </Card>
        ))}
      </div>
      <Card>
        <h2 className="font-display text-3xl text-primary">À propos</h2>
        <p className="mt-1 text-sm text-muted-foreground">Fondée par les étudiants de l'École Supérieure d'Industrie, l'équipe « The Lions of ESI » porte les couleurs bordeaux et or dans la compétition Inter-Écoles de l'INP-HB.</p>
        <h3 className="font-display mt-4 text-2xl">Hall of Fame</h3>
        {hallOfFame.map((h) => <div key={h.year} className="flex gap-3 border-t border-border py-2"><span className="font-display text-2xl text-gold-deep">{h.year}</span><span>{h.title}</span></div>)}
      </Card>
    </div>
  );
}
