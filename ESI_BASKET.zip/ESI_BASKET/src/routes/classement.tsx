import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { standings, team, initialPlayers, playerTotals } from "@/lib/data";
import { Card, Logo, Title } from "@/components/Shell";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/classement")({
  head: () => seo("Classement", "Classement complet de la compétition Inter-Écoles INP-HB et statistiques collectives."),
  component: Classement,
});

function Classement() {
  const rows = standings();
  const [sel, setSel] = useState<string | null>(null);
  const r = rows.find((x) => x.id === sel);
  return (
    <div>
      <Title kicker="Inter-Écoles INP-HB">Classement</Title>
      <Card className="overflow-x-auto p-0">
        <table className="w-full text-sm">
          <thead className="bg-muted text-xs uppercase text-muted-foreground"><tr>{["#", "École", "J", "V", "D", "PP", "PC", "Diff", "Pts"].map((h) => <th key={h} className="px-2 py-2 text-left">{h}</th>)}</tr></thead>
          <tbody>
            {rows.map((x, i) => (
              <tr key={x.id} onClick={() => setSel(x.id)} className={`cursor-pointer border-t border-border ${x.id === "esi" ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}>
                <td className="px-2 py-2 font-display text-xl">{i + 1}</td>
                <td className="px-2"><div className="flex items-center gap-2"><Logo id={x.id} className="h-7 w-7" /><b>{team(x.id).name}</b></div></td>
                <td className="px-2">{x.j}</td><td className="px-2">{x.v}</td><td className="px-2">{x.d}</td><td className="px-2">{x.pp}</td><td className="px-2">{x.pc}</td>
                <td className="px-2">{x.diff > 0 ? "+" : ""}{x.diff}</td><td className={`px-2 font-display text-xl ${x.id === "esi" ? "text-gold" : ""}`}>{x.pts}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      {r && (
        <Card className="mt-4">
          <div className="flex items-center gap-3"><Logo id={r.id} className="h-14 w-14" /><div><div className="font-display text-3xl">{team(r.id).full}</div><div className="text-sm text-muted-foreground">Moy. marquée {(r.pp / Math.max(r.j, 1)).toFixed(1)} · encaissée {(r.pc / Math.max(r.j, 1)).toFixed(1)}</div></div></div>
          {r.id === "esi" && (
            <table className="mt-4 w-full text-sm">
              <thead className="text-xs uppercase text-muted-foreground"><tr className="text-left"><th>Joueur</th><th>MJ</th><th>PTS</th><th>REB</th><th>AST</th><th>+/-</th></tr></thead>
              <tbody>{initialPlayers.map((p) => { const t = playerTotals(p.num); return (
                <tr key={p.num} className="border-t border-border"><td className="py-1">#{p.num} {p.last}</td><td>{t.gp}</td><td>{t.pts}</td><td>{t.reb}</td><td>{t.ast}</td><td>{t.pm}</td></tr>); })}</tbody>
            </table>
          )}
        </Card>
      )}
    </div>
  );
}
