import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { matches, isEsi, isPlayed, team, fmtDate, type Status } from "@/lib/data";
import { useStore, setStatus, validateConvocation, set } from "@/lib/store";
import { Card, Title } from "@/components/Shell";
import { Court } from "@/components/Court";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/coach")({
  head: () => seo("Espace Coach", "Gestion de l'effectif, des convocations et des compositions."),
  component: Coach,
});

const upcoming = matches.filter((m) => isEsi(m) && !isPlayed(m));

function Coach() {
  const [tab, setTab] = useState<"effectif" | "convoc" | "compo">("effectif");
  const players = useStore((s) => s.players);
  const convocs = useStore((s) => s.convocations);
  const lineups = useStore((s) => s.lineups);
  const [mid, setMid] = useState(upcoming[0]!.id);
  const m = upcoming.find((x) => x.id === mid)!;
  const label = `ESI vs ${team(m.home === "esi" ? m.away : m.home).name} (${fmtDate(m.date)})`;
  const [sel, setSel] = useState<number[]>([]);
  const validated = convocs[mid] ?? [];
  const lu = lineups[mid] ?? { starters: [], bench: [] };
  const [info, setInfo] = useState("");

  const toggleSel = (n: number) => setSel((s) => (s.includes(n) ? s.filter((x) => x !== n) : s.length < 12 ? [...s, n] : s));
  const setRole = (n: number, role: "starters" | "bench" | null) => set((s) => {
    const cur = s.lineups[mid] ?? { starters: [], bench: [] };
    const next = { starters: cur.starters.filter((x) => x !== n), bench: cur.bench.filter((x) => x !== n) };
    if (role === "starters" && next.starters.length < 5) next.starters.push(n);
    if (role === "bench" && next.bench.length < 7) next.bench.push(n);
    return { lineups: { ...s.lineups, [mid]: next } };
  });

  return (
    <div>
      <Title kicker="Staff technique">Espace Coach</Title>
      <div className="mb-4 flex gap-2">
        {([["effectif", "Effectif"], ["convoc", "Convocations"], ["compo", "Composition"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`rounded-full px-4 py-1.5 text-sm font-semibold ${tab === k ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{l}</button>
        ))}
      </div>
      {tab !== "effectif" && (
        <select value={mid} onChange={(e) => { setMid(e.target.value); setSel([]); }} className="mb-4 w-full rounded border border-input bg-card px-3 py-2">
          {upcoming.map((x) => <option key={x.id} value={x.id}>{fmtDate(x.date)} — {team(x.home).name} vs {team(x.away).name}</option>)}
        </select>
      )}

      {tab === "effectif" && (
        <Card className="p-0">
          {players.map((p) => (
            <div key={p.num} className="flex items-center justify-between gap-2 border-b border-border px-4 py-2 last:border-0">
              <div className="min-w-0"><b>#{p.num} {p.last}</b> <span className="text-xs text-muted-foreground">{p.pos}</span></div>
              <select value={p.status} onChange={(e) => setStatus(p.num, e.target.value as Status)} className={`shrink-0 rounded px-2 py-1 text-xs font-bold ${p.status === "actif" ? "bg-gold/30" : "bg-destructive/20 text-destructive"}`}>
                <option value="actif">Actif</option><option value="blessé">Blessé</option><option value="suspendu">Suspendu</option>
              </select>
            </div>
          ))}
        </Card>
      )}

      {tab === "convoc" && (
        <Card>
          <div className="mb-3 grid grid-cols-4 gap-2 text-center text-xs">
            {[["Effectif", 17], ["Actifs", players.filter((p) => p.status === "actif").length], ["Sélection", sel.length], ["Convoqués", validated.length]].map(([k, v]) => (
              <div key={k} className="rounded bg-muted p-2"><div className="font-display text-2xl text-primary">{v}</div>{k}</div>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
            {players.map((p) => {
              const off = p.status !== "actif";
              const on = sel.includes(p.num);
              return (
                <button key={p.num} disabled={off} onClick={() => toggleSel(p.num)} className={`rounded border px-3 py-2 text-left text-sm ${off ? "cursor-not-allowed opacity-40" : on ? "border-gold bg-primary text-primary-foreground" : "border-border"}`}>
                  #{p.num} {p.last} {off && <span className="text-[10px] uppercase">({p.status})</span>}
                </button>
              );
            })}
          </div>
          <button disabled={sel.length === 0} onClick={() => { validateConvocation(mid, sel, label); setInfo(`${sel.length} joueurs notifiés uniquement.`); }} className="mt-4 w-full rounded bg-gold py-3 font-bold text-gold-foreground disabled:opacity-40">
            Valider et notifier les {sel.length} convoqués
          </button>
          {info && <p className="mt-2 text-sm text-muted-foreground">{info}</p>}
        </Card>
      )}

      {tab === "compo" && (
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            {validated.length === 0 ? <p className="text-sm text-muted-foreground">Validez d'abord la liste des convoqués.</p> : validated.map((n) => {
              const p = players.find((x) => x.num === n)!;
              const r = lu.starters.includes(n) ? "starters" : lu.bench.includes(n) ? "bench" : null;
              return (
                <div key={n} className="flex items-center justify-between border-b border-border py-1.5 text-sm last:border-0">
                  <span>#{n} {p.last}</span>
                  <div className="flex gap-1">
                    {([["starters", "5M"], ["bench", "Remp."], [null, "—"]] as const).map(([k, l]) => (
                      <button key={l} onClick={() => setRole(n, k)} className={`rounded px-2 py-0.5 text-xs font-bold ${r === k ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{l}</button>
                    ))}
                  </div>
                </div>
              );
            })}
            <p className="mt-2 text-xs text-muted-foreground">5 majeur : {lu.starters.length}/5 · Remplaçants : {lu.bench.length}/7. Publiée au public le jour J uniquement.</p>
          </Card>
          <Court starters={lu.starters} />
        </div>
      )}
    </div>
  );
}
