import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { initialPlayers, playerTotals, team, fmtDate } from "@/lib/data";
import { Card } from "@/components/Shell";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/equipe/$num")({
  loader: ({ params }) => {
    const p = initialPlayers.find((x) => String(x.num) === params.num);
    if (!p) throw notFound();
    return { p };
  },
  head: ({ loaderData }) => loaderData ? seo(`#${loaderData.p.num} ${loaderData.p.last}`, `Fiche et statistiques de ${loaderData.p.last} ${loaderData.p.first}, ${loaderData.p.pos}.`) : seo("Joueur", "Fiche joueur"),
  component: PlayerPage,
});

function PlayerPage() {
  const { p } = Route.useLoaderData();
  const t = playerTotals(p.num);
  const avg = (v: number) => (t.gp ? (v / t.gp).toFixed(1) : "—");
  return (
    <div className="space-y-4">
      <Link to="/equipe" className="text-sm font-semibold text-primary">← Effectif</Link>
      <div className="relative overflow-hidden rounded-xl bg-primary p-6 text-primary-foreground">
        <div className="font-display absolute -right-4 -top-10 text-[12rem] leading-none text-gold/20">{p.num}</div>
        <div className="font-display text-5xl text-gold">#{p.num}</div>
        <div className="text-sm uppercase">{p.first}</div>
        <div className="font-display text-5xl leading-none">{p.last}</div>
        <div className="mt-1 opacity-80">{p.pos}</div>
      </div>
      <div className="grid grid-cols-3 gap-2 md:grid-cols-6">
        {[["MJ", t.gp], ["PTS/m", avg(t.pts)], ["REB/m", avg(t.reb)], ["AST/m", avg(t.ast)], ["STL", t.stl], ["+/-", t.pm]].map(([k, v]) => (
          <Card key={k} className="p-3 text-center"><div className="font-display text-3xl text-primary">{v}</div><div className="text-[10px] font-bold uppercase text-muted-foreground">{k}</div></Card>
        ))}
      </div>
      <Card>
        <h2 className="font-display mb-2 text-2xl">Historique des matchs</h2>
        {t.games.length === 0 ? <p className="text-sm text-muted-foreground">Aucun match joué.</p> : t.games.map(({ m, s }) => (
          <div key={m.id} className="flex justify-between border-t border-border py-2 text-sm">
            <span>{fmtDate(m.date)} · vs {team(m.home === "esi" ? m.away : m.home).name}</span>
            <span>{s.pts} pts · {s.reb} reb · {s.ast} ast · <b>{s.pm > 0 ? "+" : ""}{s.pm}</b></span>
          </div>
        ))}
      </Card>
    </div>
  );
}
