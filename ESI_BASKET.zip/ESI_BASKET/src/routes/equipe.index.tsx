import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { posGroups } from "@/lib/data";
import { useStore } from "@/lib/store";
import { Title } from "@/components/Shell";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/equipe/")({
  head: () => seo("Équipe", "Les 17 Lions de l'ESI : numéros, postes et fiches individuelles."),
  component: Equipe,
});

function Equipe() {
  const players = useStore((s) => s.players);
  const [pos, setPos] = useState<string | null>(null);
  const list = players.filter((p) => !pos || p.pos.split(" / ").includes(pos));
  return (
    <div>
      <Title kicker="Effectif officiel">Les 17 Lions</Title>
      <div className="mb-4 flex flex-wrap gap-2">
        {[null, ...posGroups].map((g) => (
          <button key={g ?? "all"} onClick={() => setPos(g)} className={`rounded-full px-3 py-1 text-sm font-semibold ${pos === g ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{g ?? "Tous"}</button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {list.map((p) => (
          <Link key={p.num} to="/equipe/$num" params={{ num: String(p.num) }} className="group relative overflow-hidden rounded-lg bg-primary p-4 text-primary-foreground">
            <div className="font-display absolute -right-2 -top-4 text-8xl text-gold/25">{p.num}</div>
            <div className="font-display text-4xl text-gold">#{p.num}</div>
            <div className="mt-6 text-xs uppercase opacity-80">{p.first}</div>
            <div className="font-display text-2xl leading-none">{p.last}</div>
            <div className="mt-1 text-xs opacity-80">{p.pos}</div>
            {p.status !== "actif" && <span className="mt-2 inline-block rounded bg-destructive px-1.5 text-[10px] font-bold uppercase">{p.status}</span>}
          </Link>
        ))}
      </div>
    </div>
  );
}
