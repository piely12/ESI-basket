import { createFileRoute, Link } from "@tanstack/react-router";
import { ClipboardList, BarChart3, User, PenSquare } from "lucide-react";
import { Title } from "@/components/Shell";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/espaces")({
  head: () => seo("Espaces privés", "Accès aux espaces Coach, Statisticienne, Joueurs et Gestion des actualités."),
  component: Espaces,
});

const spaces = [
  { to: "/coach", t: "Coach", d: "Effectif, convocations, compositions", i: ClipboardList },
  { to: "/stats", t: "Statisticienne", d: "Saisie des stats en direct", i: BarChart3 },
  { to: "/player", t: "Joueur", d: "Convocations, stats perso, notifications", i: User },
  { to: "/news-admin", t: "Actualités", d: "Articles, MVP, photos", i: PenSquare },
] as const;

function Espaces() {
  return (
    <div>
      <Title kicker="Accès staff & joueurs">Espaces privés</Title>
      <p className="mb-4 rounded border border-gold bg-gold/15 p-3 text-sm">Version maquette : les espaces sont accessibles sans connexion. La connexion et les autorisations seront ajoutées à l'étape suivante.</p>
      <div className="grid gap-3 md:grid-cols-2">
        {spaces.map((s) => (
          <Link key={s.to} to={s.to} className="flex items-center gap-4 rounded-lg border border-border bg-card p-5 hover:border-gold">
            <div className="grid h-12 w-12 shrink-0 place-items-center rounded bg-primary text-gold"><s.i /></div>
            <div><div className="font-display text-2xl">{s.t}</div><div className="text-sm text-muted-foreground">{s.d}</div></div>
          </Link>
        ))}
      </div>
    </div>
  );
}
