import { createFileRoute, Link } from "@tanstack/react-router";
import { matches, isEsi, isPlayed, TODAY, standings, team } from "@/lib/data";
import { useStore } from "@/lib/store";
import { MatchCard } from "@/components/MatchCard";
import { Card, Logo } from "@/components/Shell";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/")({
  head: () => seo("Accueil", "Prochain match, derniers résultats et actualités de l'équipe ESI Basketball à l'Inter-Écoles INP-HB."),
  component: Index,
});

function Index() {
  const esiM = matches.filter(isEsi);
  const next = esiM.filter((m) => !isPlayed(m) && m.date >= TODAY).sort((a, b) => a.date.localeCompare(b.date))[0];
  const last = esiM.filter(isPlayed).sort((a, b) => b.date.localeCompare(a.date))[0];
  const news = useStore((s) => s.news).slice(0, 3);
  const st = standings();
  const rank = st.findIndex((r) => r.id === "esi") + 1;
  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-xl bg-primary p-6 text-primary-foreground md:p-10">
        <img src={team("esi").logo} alt="" className="absolute -right-10 -top-6 h-72 w-72 opacity-15" />
        <div className="relative">
          <div className="text-xs font-bold uppercase tracking-[0.3em] text-gold">Inter-Écoles INP-HB · Saison 2026</div>
          <h1 className="font-display mt-2 text-6xl leading-[0.9] md:text-8xl">Rugir.<br /><span className="text-gold">Ensemble.</span></h1>
          <div className="mt-6 flex gap-6">
            <div><div className="font-display text-4xl text-gold">{rank}<sup className="text-lg">e</sup></div><div className="text-xs uppercase opacity-80">Classement</div></div>
            <div><div className="font-display text-4xl text-gold">{st[rank - 1]!.v}-{st[rank - 1]!.d}</div><div className="text-xs uppercase opacity-80">Bilan</div></div>
            <div><div className="font-display text-4xl text-gold">17</div><div className="text-xs uppercase opacity-80">Lions</div></div>
          </div>
        </div>
      </section>

      <div className="grid gap-4 md:grid-cols-2">
        {next && <div><h2 className="font-display mb-2 text-2xl">Prochain match</h2><MatchCard m={next} big /></div>}
        {last && <div><h2 className="font-display mb-2 text-2xl">Dernier résultat</h2><MatchCard m={last} big /></div>}
      </div>

      <section>
        <div className="mb-2 flex items-end justify-between"><h2 className="font-display text-2xl">Actualités</h2><Link to="/actualites" className="text-sm font-semibold text-primary">Tout voir →</Link></div>
        <div className="grid gap-3 md:grid-cols-3">
          {news.map((n) => (
            <Card key={n.id}>
              <span className="rounded bg-gold px-2 py-0.5 text-[10px] font-bold uppercase text-gold-foreground">{n.tag}</span>
              <h3 className="mt-2 font-semibold leading-snug">{n.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{n.body}</p>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h2 className="font-display mb-2 text-2xl">Les écoles en lice</h2>
        <div className="grid grid-cols-4 gap-3 md:grid-cols-8">
          {st.map((r) => <div key={r.id} className="flex flex-col items-center gap-1"><Logo id={r.id} className="h-14 w-14" /><span className="text-[10px] font-bold">{team(r.id).name}</span></div>)}
        </div>
      </section>
    </div>
  );
}
