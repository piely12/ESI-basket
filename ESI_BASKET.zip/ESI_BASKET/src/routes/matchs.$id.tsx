import { createFileRoute, notFound } from "@tanstack/react-router";
import { matches, initialPlayers, lineupVisible, staff, fullName } from "@/lib/data";
import { useStore } from "@/lib/store";
import { MatchCard } from "@/components/MatchCard";
import { Card } from "@/components/Shell";
import { Court } from "@/components/Court";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/matchs/$id")({
  loader: ({ params }) => {
    const m = matches.find((x) => x.id === params.id);
    if (!m) throw notFound();
    return { id: m.id };
  },
  head: () => seo("Fiche match", "Score, composition et statistiques du match."),
  component: MatchPage,
});

function MatchPage() {
  const { id } = Route.useLoaderData();
  const m = matches.find((x) => x.id === id)!;
  const saved = useStore((s) => s.lineups[id]);
  const starters = saved?.starters ?? m.starters;
  const bench = saved?.bench ?? m.bench;
  const esi = m.home === "esi" || m.away === "esi";
  const name = (n: number) => fullName(initialPlayers.find((p) => p.num === n)!);
  return (
    <div className="space-y-6">
      <MatchCard m={m} big />
      {esi && (
        <Card>
          <h2 className="font-display mb-3 text-2xl">Composition ESI</h2>
          {!lineupVisible(m) ? (
            <div className="rounded bg-muted p-6 text-center">
              <div className="font-display text-5xl text-muted-foreground">N/A</div>
              <p className="text-sm text-muted-foreground">La composition sera publiée le jour du match.</p>
            </div>
          ) : starters ? (
            <div className="grid gap-4 md:grid-cols-2">
              <Court starters={starters} />
              <div className="space-y-3 text-sm">
                <div><div className="mb-1 font-bold uppercase text-gold-deep">Remplaçants</div>{bench?.map((n) => <div key={n}>#{n} {name(n)}</div>)}</div>
                <div><div className="mb-1 font-bold uppercase text-gold-deep">Staff</div>{staff.map((s) => <div key={s}>{s}</div>)}</div>
              </div>
            </div>
          ) : <p className="text-sm text-muted-foreground">Composition en attente du coach.</p>}
        </Card>
      )}
      {m.stats && (
        <Card className="overflow-x-auto">
          <h2 className="font-display mb-3 text-2xl">Statistiques individuelles</h2>
          <table className="w-full min-w-[640px] text-sm">
            <thead className="text-xs uppercase text-muted-foreground"><tr className="text-left">
              {["Joueur", "MIN", "PTS", "REB", "AST", "STL", "BLK", "TO", "FG", "3PT", "LF", "+/-"].map((h) => <th key={h} className="py-1 pr-2">{h}</th>)}
            </tr></thead>
            <tbody>
              {m.stats.map((s) => (
                <tr key={s.num} className="border-t border-border">
                  <td className="py-1.5 pr-2 font-semibold">#{s.num} {name(s.num)}{m.starters?.includes(s.num) && <span className="ml-1 text-[10px] text-gold-deep">5M</span>}</td>
                  <td>{s.min}</td><td className="font-bold">{s.pts}</td><td>{s.reb}</td><td>{s.ast}</td><td>{s.stl}</td><td>{s.blk}</td><td>{s.to}</td>
                  <td>{s.fgm}/{s.fga}</td><td>{s.tpm}/{s.tpa}</td><td>{s.ftm}/{s.fta}</td>
                  <td className={s.pm >= 0 ? "text-gold-deep" : "text-destructive"}>{s.pm > 0 ? "+" : ""}{s.pm}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  );
}
