import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { matches, isEsi, isPlayed } from "@/lib/data";
import { MatchCard } from "@/components/MatchCard";
import { Title } from "@/components/Shell";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/matchs/")({
  head: () => seo("Matchs", "Calendrier complet de la compétition Inter-Écoles INP-HB : matchs terminés et à venir."),
  component: Matchs,
});

function Matchs() {
  const [f, setF] = useState<"tous" | "termines" | "avenir">("tous");
  const list = matches
    .filter((m) => (f === "tous" ? true : f === "termines" ? isPlayed(m) : !isPlayed(m)))
    .sort((a, b) => Number(isEsi(b)) - Number(isEsi(a)) || a.date.localeCompare(b.date));
  return (
    <div>
      <Title kicker="Calendrier">Matchs</Title>
      <div className="mb-4 flex gap-2">
        {(["tous", "termines", "avenir"] as const).map((k) => (
          <button key={k} onClick={() => setF(k)} className={`rounded-full px-4 py-1.5 text-sm font-semibold ${f === k ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
            {k === "tous" ? "Tous" : k === "termines" ? "Terminés" : "À venir"}
          </button>
        ))}
      </div>
      <div className="grid gap-3 md:grid-cols-2">{list.map((m) => <MatchCard key={m.id} m={m} />)}</div>
    </div>
  );
}
