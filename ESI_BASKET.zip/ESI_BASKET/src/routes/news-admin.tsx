import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { TODAY, initialPlayers } from "@/lib/data";
import { useStore, set } from "@/lib/store";
import { Card, Title } from "@/components/Shell";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/news-admin")({
  head: () => seo("Gestion des actualités", "Création et gestion des articles, MVP et photos."),
  component: NewsAdmin,
});

const schema = z.object({ title: z.string().trim().min(3).max(120), body: z.string().trim().min(5).max(2000), tag: z.string() });
const blank = { id: "", title: "", body: "", tag: "Actu", mvp: 0, photo: "" };

function NewsAdmin() {
  const news = useStore((s) => s.news);
  const [f, setF] = useState(blank);
  const [err, setErr] = useState("");
  const save = () => {
    const r = schema.safeParse(f);
    if (!r.success) return setErr("Titre (3+) et contenu (5+) requis.");
    const item = { id: f.id || `n${Date.now()}`, title: f.title, body: f.body, tag: f.tag, date: TODAY, mvp: f.mvp || undefined };
    set((s) => ({ news: f.id ? s.news.map((n) => (n.id === f.id ? item : n)) : [item, ...s.news] }));
    setF(blank); setErr("");
  };
  return (
    <div className="space-y-4">
      <Title kicker="CMS">Gestion des actualités</Title>
      <Card className="space-y-2">
        <input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="Titre" className="w-full rounded border border-input bg-background px-3 py-2" />
        <textarea value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} rows={4} placeholder="Contenu" className="w-full rounded border border-input bg-background px-3 py-2" />
        <div className="grid grid-cols-2 gap-2">
          <select value={f.tag} onChange={(e) => setF({ ...f, tag: e.target.value })} className="rounded border border-input bg-background px-3 py-2">
            {["Actu", "Match", "MVP", "5 majeur de la semaine", "Indisponibilité", "Avant-match"].map((t) => <option key={t}>{t}</option>)}
          </select>
          <select value={f.mvp} onChange={(e) => setF({ ...f, mvp: Number(e.target.value) })} className="rounded border border-input bg-background px-3 py-2">
            <option value={0}>Pas de MVP</option>
            {initialPlayers.map((p) => <option key={p.num} value={p.num}>MVP : #{p.num} {p.last}</option>)}
          </select>
        </div>
        <label className="block rounded border border-dashed border-border p-3 text-center text-sm text-muted-foreground">
          {f.photo || "Ajouter une photo (JPG/PNG, 5 Mo max)"}
          <input type="file" accept="image/png,image/jpeg" className="hidden" onChange={(e) => { const x = e.target.files?.[0]; if (x && x.size <= 5e6) setF({ ...f, photo: x.name }); }} />
        </label>
        {err && <p className="text-sm text-destructive">{err}</p>}
        <div className="flex gap-2">
          <button onClick={save} className="flex-1 rounded bg-primary py-2 font-semibold text-primary-foreground">{f.id ? "Mettre à jour" : "Publier"}</button>
          {f.id && <button onClick={() => setF(blank)} className="rounded bg-muted px-4">Annuler</button>}
        </div>
      </Card>
      <Card className="p-0">
        {news.map((n) => (
          <div key={n.id} className="flex items-center justify-between gap-2 border-b border-border px-4 py-2 last:border-0">
            <div className="min-w-0"><div className="truncate font-semibold">{n.title}</div><div className="text-xs text-muted-foreground">{n.tag} · {n.date}</div></div>
            <div className="flex shrink-0 gap-1">
              <button onClick={() => setF({ id: n.id, title: n.title, body: n.body, tag: n.tag, mvp: n.mvp ?? 0, photo: "" })} className="rounded bg-muted px-2 py-1 text-xs">Modifier</button>
              <button onClick={() => set((s) => ({ news: s.news.filter((x) => x.id !== n.id) }))} className="rounded bg-destructive/20 px-2 py-1 text-xs text-destructive">Supprimer</button>
            </div>
          </div>
        ))}
      </Card>
    </div>
  );
}
