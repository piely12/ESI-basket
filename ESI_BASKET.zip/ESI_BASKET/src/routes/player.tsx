import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { matches, team, fmtDate, playerTotals } from "@/lib/data";
import { useStore, set } from "@/lib/store";
import { Card, Title } from "@/components/Shell";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/player")({
  head: () => seo("Espace Joueur", "Convocations, statistiques personnelles et notifications."),
  component: PlayerSpace,
});

function PlayerSpace() {
  const players = useStore((s) => s.players);
  const convocs = useStore((s) => s.convocations);
  const allNotifs = useStore((s) => s.notifs);
  const [num, setNum] = useState(1);
  const me = players.find((p) => p.num === num)!;
  const notifs = allNotifs.filter((n) => n.to === num);
  const myConv = Object.entries(convocs).filter(([, l]) => l.includes(num)).map(([id]) => matches.find((m) => m.id === id)!);
  const t = playerTotals(num);
  return (
    <div className="space-y-4">
      <Title kicker="Mon espace">Espace Joueur</Title>
      <select value={num} onChange={(e) => setNum(Number(e.target.value))} className="w-full rounded border border-input bg-card px-3 py-2">
        {players.map((p) => <option key={p.num} value={p.num}>Connecté en tant que #{p.num} {p.last} {p.first}</option>)}
      </select>
      <div className="grid grid-cols-4 gap-2">
        {[["MJ", t.gp], ["PTS", t.pts], ["REB", t.reb], ["+/-", t.pm]].map(([k, v]) => (
          <Card key={k} className="p-3 text-center"><div className="font-display text-3xl text-primary">{v}</div><div className="text-[10px] font-bold uppercase">{k}</div></Card>
        ))}
      </div>
      <Link to="/equipe/$num" params={{ num: String(num) }} className="block text-sm font-semibold text-primary">Voir ma fiche complète →</Link>
      <Card>
        <h2 className="font-display text-2xl">Mes convocations</h2>
        <p className="text-xs text-muted-foreground">Statut : {me.status}</p>
        {myConv.length === 0 ? <p className="mt-2 text-sm text-muted-foreground">Aucune convocation pour le moment.</p> : myConv.map((m) => (
          <div key={m.id} className="mt-2 rounded bg-gold/20 p-2 text-sm font-semibold">{fmtDate(m.date)} {m.time} — {team(m.home).name} vs {team(m.away).name} · {m.venue}</div>
        ))}
      </Card>
      <Card>
        <h2 className="font-display text-2xl">Notifications ({notifs.filter((n) => !n.read).length})</h2>
        {notifs.length === 0 ? <p className="mt-2 text-sm text-muted-foreground">Rien de nouveau.</p> : notifs.map((n) => (
          <button key={n.id} onClick={() => set((s) => ({ notifs: s.notifs.map((x) => (x.id === n.id ? { ...x, read: true } : x)) }))} className={`mt-2 block w-full rounded border p-2 text-left text-sm ${n.read ? "border-border opacity-60" : "border-gold"}`}>{n.text}</button>
        ))}
      </Card>
    </div>
  );
}
