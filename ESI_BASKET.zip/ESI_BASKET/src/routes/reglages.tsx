import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { Card, Title } from "@/components/Shell";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/reglages")({
  head: () => seo("Réglages", "FAQ, confidentialité, thème clair/sombre et contact de l'équipe ESI Basketball."),
  component: Reglages,
});

const schema = z.object({ pseudo: z.string().trim().min(2).max(40), message: z.string().trim().min(5).max(1000) });
const faq = [
  ["Quand les résultats sont-ils publiés ?", "Au plus tard 48h après chaque match."],
  ["Pourquoi la composition affiche N/A ?", "Elle n'est dévoilée que le jour du match."],
  ["Comment rejoindre l'équipe ?", "Contactez le staff via le formulaire ci-dessous."],
];

function Reglages() {
  const [dark, setDark] = useState(false);
  const [form, setForm] = useState({ pseudo: "", message: "" });
  const [msg, setMsg] = useState("");
  useEffect(() => { setDark(document.documentElement.classList.contains("dark")); }, []);
  const toggle = () => { document.documentElement.classList.toggle("dark"); setDark(!dark); };
  return (
    <div className="space-y-4">
      <Title kicker="Préférences">Réglages</Title>
      <Card className="flex items-center justify-between"><span className="font-semibold">Mode sombre</span>
        <button onClick={toggle} className={`h-7 w-12 rounded-full p-1 transition ${dark ? "bg-gold" : "bg-muted"}`}><span className={`block h-5 w-5 rounded-full bg-primary transition ${dark ? "translate-x-5" : ""}`} /></button>
      </Card>
      <Card><h2 className="font-display mb-2 text-2xl">FAQ</h2>{faq.map(([q, a]) => <details key={q} className="border-t border-border py-2"><summary className="cursor-pointer font-semibold">{q}</summary><p className="text-sm text-muted-foreground">{a}</p></details>)}</Card>
      <Card><h2 className="font-display mb-2 text-2xl">Confidentialité</h2><p className="text-sm text-muted-foreground">Seul un pseudonyme est demandé pour nous contacter. Les données des joueurs ne sont accessibles qu'au staff autorisé.</p></Card>
      <Card>
        <h2 className="font-display mb-2 text-2xl">Contact</h2>
        <form className="space-y-2" onSubmit={(e) => { e.preventDefault(); const r = schema.safeParse(form); if (!r.success) return setMsg("Pseudonyme (2+ car.) et message (5+ car.) requis."); setMsg("Merci ! Message envoyé (démo)."); setForm({ pseudo: "", message: "" }); }}>
          <input value={form.pseudo} onChange={(e) => setForm({ ...form, pseudo: e.target.value })} maxLength={40} placeholder="Pseudonyme" className="w-full rounded border border-input bg-background px-3 py-2" />
          <textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} maxLength={1000} rows={4} placeholder="Votre message" className="w-full rounded border border-input bg-background px-3 py-2" />
          <button className="rounded bg-primary px-4 py-2 font-semibold text-primary-foreground">Envoyer</button>
          {msg && <p className="text-sm">{msg}</p>}
        </form>
      </Card>
    </div>
  );
}
