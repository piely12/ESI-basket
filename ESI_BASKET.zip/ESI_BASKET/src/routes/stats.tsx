import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { matches, initialPlayers, type StatLine } from "@/lib/data";
import { useStore, set } from "@/lib/store";
import { Card, Title } from "@/components/Shell";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/stats")({
  head: () => seo("Espace Statisticienne", "Saisie rapide des statistiques en direct pendant les matchs."),
  component: Stats,
});

const live = matches.find((m) => m.id === "m4")!;
const empty = (num: number): StatLine => ({ num, min: 0, pts: 0, reb: 0, ast: 0, stl: 0, blk: 0, to: 0, fgm: 0, fga: 0, tpm: 0, tpa: 0, ftm: 0, fta: 0, pm: 0 });
const actions: { l: string; f: (s: StatLine) => Partial<StatLine> }[] = [
  { l: "+2", f: (s) => ({ pts: s.pts + 2, fgm: s.fgm + 1, fga: s.fga + 1 }) },
  { l: "+3", f: (s) => ({ pts: s.pts + 3, fgm: s.fgm + 1, fga: s.fga + 1, tpm: s.tpm + 1, tpa: s.tpa + 1 }) },
  { l: "LF", f: (s) => ({ pts: s.pts + 1, ftm: s.ftm + 1, fta: s.fta + 1 }) },
  { l: "Raté 2", f: (s) => ({ fga: s.fga + 1 }) },
  { l: "Raté 3", f: (s) => ({ fga: s.fga + 1, tpa: s.tpa + 1 }) },
  { l: "LF raté", f: (s) => ({ fta: s.fta + 1 }) },
  { l: "REB", f: (s) => ({ reb: s.reb + 1 }) },
  { l: "AST", f: (s) => ({ ast: s.ast + 1 }) },
  { l: "STL", f: (s) => ({ stl: s.stl + 1 }) },
  { l: "BLK", f: (s) => ({ blk: s.blk + 1 }) },
  { l: "TO", f: (s) => ({ to: s.to + 1 }) },
  { l: "+/- ↑", f: (s) => ({ pm: s.pm + 1 }) },
  { l: "+/- ↓", f: (s) => ({ pm: s.pm - 1 }) },
];

function Stats() {
  const roster = [...(live.starters ?? []), ...(live.bench ?? [])];
  const stats = useStore((s) => s.liveStats);
  const validated = useStore((s) => s.statsValidated);
  const [cur, setCur] = useState<number>(roster[0]!);
  const [hist, setHist] = useState<StatLine[]>([]);
  const [confirm, setConfirm] = useState(false);
  const line = stats[cur] ?? empty(cur);
  const total = Object.values(stats).reduce((a, s) => a + s.pts, 0);

  const apply = (f: (s: StatLine) => Partial<StatLine>) => {
    if (validated) return;
    setHist((h) => [line, ...h].slice(0, 30));
    set((s) => ({ liveStats: { ...s.liveStats, [cur]: { ...line, ...f(line) } } }));
  };
  const undo = () => { const [last, ...rest] = hist; if (!last) return; setHist(rest); set((s) => ({ liveStats: { ...s.liveStats, [last.num]: last } })); };

  return (
    <div>
      <Title kicker="En direct · ESI vs ESMG">Saisie des stats</Title>
      <div className="mb-3 flex items-center justify-between rounded-lg bg-primary p-3 text-primary-foreground">
        <span className="text-sm">Points ESI saisis</span><span className="font-display text-4xl text-gold">{total}</span>
      </div>
      <div className="mb-3 grid grid-cols-6 gap-1.5">
        {roster.map((n) => (
          <button key={n} onClick={() => setCur(n)} className={`font-display rounded py-2 text-2xl ${cur === n ? "bg-gold text-gold-foreground" : "bg-muted"}`}>{n}</button>
        ))}
      </div>
      <Card className="mb-3 p-3 text-sm">
        <b>#{cur} {initialPlayers.find((p) => p.num === cur)!.last}</b> — {line.pts} pts · {line.reb} reb · {line.ast} ast · {line.stl} stl · {line.blk} blk · {line.to} to · FG {line.fgm}/{line.fga} · 3PT {line.tpm}/{line.tpa} · LF {line.ftm}/{line.fta} · +/- {line.pm}
      </Card>
      <div className="grid grid-cols-3 gap-2 md:grid-cols-5">
        {actions.map((a) => (
          <button key={a.l} disabled={validated} onClick={() => apply(a.f)} className="rounded-lg border border-border bg-card py-4 text-lg font-bold active:scale-95 disabled:opacity-40">{a.l}</button>
        ))}
        <button onClick={undo} disabled={!hist.length || validated} className="rounded-lg bg-muted py-4 font-bold disabled:opacity-40">↶ Annuler</button>
      </div>
      <div className="mt-4">
        {validated ? (
          <p className="rounded bg-gold/30 p-3 text-center font-semibold">Stats validées et verrouillées pour publication.</p>
        ) : confirm ? (
          <div className="flex gap-2">
            <button onClick={() => { set((s) => ({ statsValidated: true, audit: [`${new Date().toISOString()} — stats m4 validées (${total} pts)`, ...s.audit] })); setConfirm(false); }} className="flex-1 rounded bg-primary py-3 font-bold text-primary-foreground">Confirmer ({total} pts)</button>
            <button onClick={() => setConfirm(false)} className="rounded bg-muted px-4">Retour</button>
          </div>
        ) : (
          <button onClick={() => setConfirm(true)} className="w-full rounded bg-gold py-3 font-bold text-gold-foreground">Valider avant publication</button>
        )}
      </div>
    </div>
  );
}
